feedly-simplify
===============

This Chrome extension restyles/simplifies the interface of Feedly and add the shift+B shortcut to open an rss item an a new background tab

See See https://chrome.google.com/webstore/detail/feedly-simplify/fgepkmmkpkdoppdjenceolgjbdcfiekb for the published version

## How to create a new version

* Bump the version number in manifest.json
* ./make.sh
